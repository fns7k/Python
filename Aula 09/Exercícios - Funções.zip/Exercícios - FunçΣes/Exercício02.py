# Exercício 2
# Faça um programa em Python que tenha uma função chamada escreva(), que receba um texto qualquer como parâmetro e mostre uma mensagem como o exemplo abaixo.



def escreva(texto):
    escrito = texto
    return escrito

texto = input("Digite a um texto: ")

print("\nO texto escrito foi:", escreva(texto))