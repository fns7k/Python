# Exercício 4
# Faça um programa que tenha uma lista chamada números e duas funções chamadas sorteio() e somaPar(). 
# A primeira função vai sortear 5 números de 1 a 10 e vai coloca-los dentro da lista e a segunda função vai mostrar a soma entre todos os valores PARES sorteados pela função anterior.



import random

def sorteio():
    numeros = []
    for _ in range(5):
        numeros.append(random.randint(1, 10))
    return numeros

def somaPar(lista):
    soma = 0
    for num in lista:
        if num % 2 == 0:
            soma += num
    return soma

# Sorteando os números
numerosSorteados = sorteio()

# Calculando a soma dos números pares
soma_pares = somaPar(numerosSorteados)

print("Números sorteados:", numerosSorteados)
print("Soma dos números pares:", soma_pares)
