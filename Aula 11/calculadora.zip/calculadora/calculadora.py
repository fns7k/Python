import sys
from PyQt6.QtWidgets import QApplication, QWidget, QPushButton, QLineEdit, QVBoxLayout 
from PyQt6.QtCore import Qt

def calcular():
    expressao = inputCalculadora.text()
    try:
        resultado = eval(expressao)     # Função eval --> calcula um conjunto numérico
        inputCalculadora.setText(str(resultado))        # Como "setText()" espera uma string como argumento, o resultado é convertido para string usando str().
    except Exception as erro:       # Se ocorrer algum erro durante a execução do bloco try, ele será capturado e armazenado na variável "erro".
        inputCalculadora.setText("Erro")

def limpar():
    inputCalculadora.setText("0")

def inverterSinal():
    expressao = inputCalculadora.text()
    if expressao[0] == '-':     # O código verifica se o primeiro caractere da expressão inserida é um sinal de menos "-"
        inputCalculadora.setText(expressao[1:])     # Se o primeiro caractere for "-", ele remove esse sinal negativo
    else:
        inputCalculadora.setText('-' + expressao)       # Ele adiciona um sinal de menos "-" à frente da expressão

def adicionarAoInput(valor):
    if inputCalculadora.text() == "0":
        inputCalculadora.setText(valor)
    else:
        inputCalculadora.setText(inputCalculadora.text() + valor)

app = QApplication(sys.argv)
janela = QWidget()
janela.resize(400, 520)
janela.setWindowTitle("Calculadora")

tamanhoBotao = 81

# Le o conteudo do arquivo CSS
with open('Aula 11/calculadora/style.css', 'r') as style_file:
    styles = style_file.read()

# Aplicar o Estilo a janela
janela.setStyleSheet(styles)

# Adicionando o Input
inputCalculadora = QLineEdit('0', janela)
inputCalculadora.move(39,20)
inputCalculadora.setReadOnly(True)
inputCalculadora.resize(322, 65) # Define o tamanho da janela
inputCalculadora.setAlignment(Qt.AlignmentFlag.AlignRight) # Alinha na direita

# Adicionar os botões 1ªlinha
btnAC = QPushButton('AC' , janela)
btnAC.setGeometry(39, 90, tamanhoBotao , tamanhoBotao)
btnAC.setObjectName('btnAC')
btnAC.clicked.connect(limpar)

btnE = QPushButton('+/-' , janela)
btnE.setGeometry(119, 90, tamanhoBotao , tamanhoBotao)
btnE.setObjectName('btnE')
btnE.clicked.connect(inverterSinal)

btnP = QPushButton('%' , janela)
btnP.setGeometry(199, 90, tamanhoBotao , tamanhoBotao)
btnP.setObjectName('btnP')
btnP.clicked.connect(lambda: adicionarAoInput('%'))

btnB = QPushButton('/' , janela)
btnB.setGeometry(280, 90, tamanhoBotao , tamanhoBotao)
btnB.setObjectName('btnB')
btnB.clicked.connect(lambda: adicionarAoInput('/'))

# Adicionar os botões 2ªlinha
btn7 = QPushButton('7' , janela)
btn7.setGeometry(39, 170, tamanhoBotao , tamanhoBotao)
btn7.clicked.connect(lambda: adicionarAoInput('7'))

btn8 = QPushButton('8' , janela)
btn8.setGeometry(119, 170, tamanhoBotao , tamanhoBotao)
btn8.setObjectName('btn8')
btn8.clicked.connect(lambda: adicionarAoInput('8'))

btn9 = QPushButton('9' , janela)
btn9.setGeometry(199, 170, tamanhoBotao , tamanhoBotao)
btn9.setObjectName('btn9')
btn9.clicked.connect(lambda: adicionarAoInput('9'))

btnX = QPushButton('X' , janela)
btnX.setGeometry(280, 170, tamanhoBotao , tamanhoBotao)
btnX.setObjectName('btnX')
btnX.clicked.connect(lambda: adicionarAoInput('*'))

# Adicionar os botões 3ªlinha
btn4 = QPushButton('4' , janela)
btn4.setGeometry(39, 250, tamanhoBotao , tamanhoBotao)
btn4.clicked.connect(lambda: adicionarAoInput('4'))

btn5 = QPushButton('5' , janela)
btn5.setGeometry(119, 250, tamanhoBotao , tamanhoBotao)
btn5.setObjectName('btn5')
btn5.clicked.connect(lambda: adicionarAoInput('5'))

btn6 = QPushButton('6' , janela)
btn6.setGeometry(199, 250, tamanhoBotao , tamanhoBotao)
btn6.setObjectName('btn6')
btn6.clicked.connect(lambda: adicionarAoInput('6'))

btnMe = QPushButton('-' , janela)
btnMe.setGeometry(280, 250, tamanhoBotao , tamanhoBotao)
btnMe.setObjectName('btnMe')
btnMe.clicked.connect(lambda: adicionarAoInput('-'))

# Adicionar os botões 4ªlinha
btn1 = QPushButton('1' , janela)
btn1.setGeometry(39, 330, tamanhoBotao , tamanhoBotao)
btn1.clicked.connect(lambda: adicionarAoInput('1'))

btn2 = QPushButton('2' , janela)
btn2.setGeometry(119, 330, tamanhoBotao , tamanhoBotao)
btn2.setObjectName('btn5')
btn2.clicked.connect(lambda: adicionarAoInput('2'))

btn3 = QPushButton('3' , janela)
btn3.setGeometry(199, 330, tamanhoBotao , tamanhoBotao)
btn3.setObjectName('btn6')
btn3.clicked.connect(lambda: adicionarAoInput('3'))

btnMa = QPushButton('+' , janela)
btnMa.setGeometry(280, 330, tamanhoBotao , tamanhoBotao)
btnMa.setObjectName('btnMa')
btnMa.clicked.connect(lambda: adicionarAoInput('+'))

# Adicionar os botões 5ªlinha
btn0 = QPushButton('0' , janela)
btn0.setGeometry(39, 410, tamanhoBotao , tamanhoBotao)
btn0.clicked.connect(lambda: adicionarAoInput('0'))

btnV = QPushButton(',' , janela)
btnV.setGeometry(119, 410, tamanhoBotao , tamanhoBotao)
btnV.setObjectName('btn5')
btnV.clicked.connect(lambda: adicionarAoInput('.'))

btnR = QPushButton('√' , janela)
btnR.setGeometry(199, 410, tamanhoBotao , tamanhoBotao)
btnR.setObjectName('btnR')
btnR.clicked.connect(lambda: adicionarAoInput('**0.5'))

btnI = QPushButton('=' , janela)
btnI.setGeometry(280, 410, tamanhoBotao , tamanhoBotao)
btnI.setObjectName('btnI')
btnI.clicked.connect(calcular)

janela.show()
sys.exit(app.exec())
